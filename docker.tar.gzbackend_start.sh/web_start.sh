#/bin/bash
cd templates
yarn install
nohup quasar d &
